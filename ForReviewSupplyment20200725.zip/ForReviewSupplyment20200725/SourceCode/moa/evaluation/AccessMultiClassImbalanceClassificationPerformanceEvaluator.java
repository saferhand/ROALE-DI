/*
 *    BasicClassificationPerformanceEvaluator.java
 *    Copyright (C) 2007 University of Waikato, Hamilton, New Zealand
 *    @author Richard Kirkby (rkirkby@cs.waikato.ac.nz)
 *    @author Albert Bifet (abifet at cs dot waikato dot ac dot nz)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.evaluation;

import moa.AbstractMOAObject;
import moa.core.Example;
import moa.core.Measurement;
import moa.core.ObjectRepository;
import moa.core.Utils;

import com.github.javacliparser.FloatOption;
import com.github.javacliparser.IntOption;
import com.yahoo.labs.samoa.instances.Instance;
import com.yahoo.labs.samoa.instances.InstanceData;
import com.yahoo.labs.samoa.instances.Prediction;
import moa.options.AbstractOptionHandler;
import moa.tasks.TaskMonitor;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * Classification evaluator that performs basic incremental evaluation.
 *
 * @author Richard Kirkby (rkirkby@cs.waikato.ac.nz)
 * @author Albert Bifet (abifet at cs dot waikato dot ac dot nz)
 * @version $Revision: 7 $
 */
public class AccessMultiClassImbalanceClassificationPerformanceEvaluator extends AbstractOptionHandler
        implements LearningPerformanceEvaluator<Example<Instance>> {

	//Settings
    public FloatOption FscoreOption = new FloatOption("FscoreOption",
            'f', "Relative importance of recall and precision in Fscore.",
            1.00, 0.00, Float.MAX_VALUE);

    private static final long serialVersionUID = 1L;

    protected Estimator weightCorrect;//all correct predicted

    protected Estimator[] columnKappa;//instance of each class

    protected Estimator[] rowKappa;//predicted as each class
    
    protected double[] numberinstance;//number of instance in each class TP+FN
      
    protected double[] predictinstance;//number of instance predicted as each class TP+FP
    
    protected double[] truepositive;//TP
    
    protected int numClasses;//number of classes of the processed stream

    private Estimator weightCorrectNoChangeClassifier;//

    private Estimator weightMajorityClassifier;

    private int lastSeenClass;//rt

    private double totalWeightObserved;//sum of all the weight in the data stream
    //
    @Override
    public void reset() {
        reset(this.numClasses);
    }
    //reset when first learn
    public void reset(int numClasses) {
        this.numClasses = numClasses;
        this.rowKappa = new  Estimator[numClasses];
        this.columnKappa = new  Estimator[numClasses];
        this.numberinstance = new double[numClasses];
        this.predictinstance = new double[numClasses];
        this.truepositive = new double[numClasses];
        for (int i = 0; i < this.numClasses; i++) {
            this.rowKappa[i] = newEstimator();
            this.columnKappa[i] = newEstimator();
            this.numberinstance[i] = 0;
            this.predictinstance[i] = 0;
            this.truepositive[i] = 0;
        }
        this.weightCorrect = newEstimator();
        this.weightCorrectNoChangeClassifier = newEstimator();
        this.weightMajorityClassifier = newEstimator();
        this.lastSeenClass = 0;
        this.totalWeightObserved = 0;
    }
    //main function
    @Override
    public void addResult(Example<Instance> example, double[] classVotes) {
        Instance inst = example.getData();
        double weight = inst.weight();
        if (inst.classIsMissing() == false){
            int trueClass = (int) inst.classValue();
            int predictedClass = Utils.maxIndex(classVotes);
            if (weight > 0.0) {
            	//reset the evaluator at the first time
                if (this.totalWeightObserved == 0) {
                    reset(inst.dataset().numClasses());
                }
                this.numberinstance[trueClass]+= weight;
                this.predictinstance[predictedClass]+= weight;
                if (trueClass==predictedClass) {
                	this.truepositive[trueClass]+= weight;
                }
                this.totalWeightObserved += weight;
                this.weightCorrect.add(predictedClass == trueClass ? weight : 0);
                for (int i = 0; i < this.numClasses; i++) {
                    this.rowKappa[i].add(predictedClass == i ? weight: 0);
                    this.columnKappa[i].add(trueClass == i ? weight: 0);
                }
            }
            this.weightCorrectNoChangeClassifier.add(this.lastSeenClass == trueClass ? weight: 0);
            this.weightMajorityClassifier.add(getMajorityClass() == trueClass ? weight: 0);
            this.lastSeenClass = trueClass;
        }
    }
    //which class is the majority of the datasets
    private int getMajorityClass() {
        int majorityClass = 0;
        double maxProbClass = 0.0;
        for (int i = 0; i < this.numClasses; i++) {
            if (this.columnKappa[i].estimation() > maxProbClass) {
                majorityClass = i;
                maxProbClass = this.columnKappa[i].estimation();
            }
        }
        return majorityClass;
    }
    //
    @Override
    public Measurement[] getPerformanceMeasurements() {
    	List<Measurement> measurementList = new LinkedList<Measurement>();
    	
    	measurementList.add(new Measurement("classified instances",getTotalWeightObserved()));
    	measurementList.add(new Measurement("classifications correct (percent)",getFractionCorrectlyClassified() * 100.0));
    	measurementList.add(new Measurement("Kappa Statistic (percent)",getKappaStatistic() * 100.0));
    	measurementList.add(new Measurement("Kappa Temporal Statistic (percent)",getKappaTemporalStatistic() * 100.0));
    	measurementList.add(new Measurement("Kappa M Statistic (percent)",getKappaMStatistic() * 100.0));
        for (int i = 0; i < this.numClasses; i++) {
        	String s = String.valueOf(i);
        	measurementList.add(new Measurement("Recall"+s,getRecall(i) * 100.0));
        	measurementList.add(new Measurement("Precision"+s,getPrecision(i) * 100.0));
        	measurementList.add(new Measurement("Fscore"+s,getFscore(i) * 100.0));
        	measurementList.add(new Measurement("Gmeans"+s,getGmeans(i) * 100.0));
        }
    	return measurementList.toArray(new Measurement[measurementList.size()]);
    }
    //Recall
    public double getRecall(int calledclass) {
    	if (this.numberinstance[calledclass]==0) {
    		return 0;
    	}
    	return this.truepositive[calledclass]/this.numberinstance[calledclass];
    }
    //Precision
    public double getPrecision(int calledclass) {
    	if (this.predictinstance[calledclass]==0) {
    		return 0;
    	}
    	return this.truepositive[calledclass]/this.predictinstance[calledclass];
    }
    //Fscore
    public double getFscore(int calledclass) {
    	double recallvalue = this.truepositive[calledclass]/this.numberinstance[calledclass];
    	double precisionvalue = this.truepositive[calledclass]/this.predictinstance[calledclass];
    	double relativevalue = this.FscoreOption.getValue();
    	double fscore = ((1+ relativevalue*relativevalue)*recallvalue*precisionvalue)/(relativevalue*relativevalue*precisionvalue+recallvalue);
    	if ((relativevalue*relativevalue*precisionvalue+recallvalue)==0)
    		fscore = 0;
    	return fscore;
    }
    //Gmeans
    public double getGmeans(int calledclass) {
    	double recallvalue = this.truepositive[calledclass]/this.numberinstance[calledclass];
    	double truenegative = 0;
    	double tnfp = 0;
    	for(int i = 0; i < this.numClasses; i++) {
    		truenegative += (i == calledclass ? 0 : this.truepositive[i]);
    		tnfp += (i == calledclass ? 0 : this.numberinstance[i]);
    	}
    	if (this.numberinstance[calledclass]==0||tnfp==0) {
    		return 0;
    	}
    	double gmeans = Math.sqrt(recallvalue*truenegative/tnfp);
    	return gmeans;
    }
    //total weight
    public double getTotalWeightObserved() {
        return this.totalWeightObserved;
    }
    //correct accuracy
    public double getFractionCorrectlyClassified() {
        return this.weightCorrect.estimation();
    }
    //1-accuracy
    public double getFractionIncorrectlyClassified() {
        return 1.0 - getFractionCorrectlyClassified();
    }
    //
    public double getKappaStatistic() {
        if (this.getTotalWeightObserved() > 0.0) {
            double p0 = getFractionCorrectlyClassified();
            double pc = 0.0;
            for (int i = 0; i < this.numClasses; i++) {
                pc += this.rowKappa[i].estimation()
                        * this.columnKappa[i].estimation();
            }
            return (p0 - pc) / (1.0 - pc);
        } else {
            return 0;
        }
    }
    //
    public double getKappaTemporalStatistic() {
        if (this.getTotalWeightObserved() > 0.0) {
            double p0 = getFractionCorrectlyClassified();
            double pc = this.weightCorrectNoChangeClassifier.estimation();

            return (p0 - pc) / (1.0 - pc);
        } else {
            return 0;
        }
    }
    //
    private double getKappaMStatistic() {
        if (this.getTotalWeightObserved() > 0.0) {
            double p0 = getFractionCorrectlyClassified();
            double pc = this.weightMajorityClassifier.estimation();

            return (p0 - pc) / (1.0 - pc);
        } else {
            return 0;
        }
    }
    //
    @Override
    public void getDescription(StringBuilder sb, int indent) {
        Measurement.getMeasurementsDescription(getPerformanceMeasurements(),
                sb, indent);
    }
    //
	@Override
	public void addResult(Example<Instance> testInst, Prediction prediction) {
		// TODO Auto-generated method stub
		
	}
	//
    @Override
    protected void prepareForUseImpl(TaskMonitor monitor, ObjectRepository repository) {

    }
    //
    public interface Estimator extends Serializable {

        void add(double value);

        double estimation();
    }
    //implement of Estimator
    public class BasicEstimator implements Estimator {

        protected double len;

        protected double sum;

        @Override
        public void add(double value) {
            sum += value;
            len++;
        }

        @Override
        public double estimation(){
            return sum/len;
        }

    }
    //used for reset a new Estimator
    protected Estimator newEstimator() {
        return new BasicEstimator();
    }
}

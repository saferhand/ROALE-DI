/*
 *    ActiveChunkEvaluatePrequential.java
 *    Copyright (C) 2017 National University of Defense Technology, Changsha, China
 *    @author Shan Jicheng(shanjicheng@nudt.edu.cn)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.tasks;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import moa.classifiers.Classifier;
import moa.classifiers.active.OALE;
import moa.core.Example;
import moa.core.InstanceExample;
import moa.core.Measurement;
import moa.core.ObjectRepository;
import moa.core.TimingUtils;
import moa.core.Utils;
import moa.evaluation.LearningCurve;
import moa.evaluation.LearningEvaluation;
import moa.evaluation.LearningPerformanceEvaluator;
import moa.learners.Learner;
import moa.options.ClassOption;
import com.github.javacliparser.FileOption;
import com.github.javacliparser.IntOption;
import moa.streams.ExampleStream;
import moa.streams.InstanceStream;
import com.yahoo.labs.samoa.instances.Instance;
import com.yahoo.labs.samoa.instances.Instances;

public class OALETask extends MainTask {

	@Override
	public String getPurposeString() {
		return "Evaluates a classifier on a stream by testing then training with chunks of data in sequence.";
	}
	
	private static final long serialVersionUID = 1L;

	/**
	 *  the trained classifier.
	 */
	public ClassOption learnerOption = new ClassOption("learner", 'l',
			"Classifier to train.", OALE.class, "moa.classifiers.active.OALE");
	
	/**
	 * Allows to select the stream the classifier will learn. 
	 */
	public ClassOption streamOption = new ClassOption("stream", 's',
			"Stream to learn from.", ExampleStream.class,
			"ArffFileStream");

	/**
	 * Allows to select the classifier performance evaluation method.
	 */
	public ClassOption evaluatorOption = new ClassOption("evaluator", 'e',
            "Learning performance evaluation method.",
            LearningPerformanceEvaluator.class,
			"BasicClassificationPerformanceEvaluator");

	/**
	 * Allows to define the maximum number of instances to test/train on  (-1 = no limit).
	 */
	public IntOption instanceLimitOption = new IntOption("instanceLimit", 'i',
			"Maximum number of instances to test/train on  (-1 = no limit).",
			10000000, -1, Integer.MAX_VALUE);

	/**
	 * Allow to define the training/testing chunk size.
	 */
	public IntOption chunkSizeOption = new IntOption("chunkSize", 'c',
			"Number of instances in a data chunk.",
			500, 1, Integer.MAX_VALUE);
	
	/**
	 * Allows to define the maximum number of seconds to test/train for (-1 = no limit).
	 */
	public IntOption timeLimitOption = new IntOption("timeLimit", 't',
			"Maximum number of seconds to test/train for (-1 = no limit).", -1,
			-1, Integer.MAX_VALUE);

	/**
	 * Defines how often classifier parameters will be calculated.
	 */
	public IntOption sampleFrequencyOption = new IntOption("sampleFrequency",
			'f',
			"How many instances between samples of the learning performance.",
			1000, 0, Integer.MAX_VALUE);

	/**
	 * Allows to define the memory limit for the created model.
	 */
	public IntOption maxMemoryOption = new IntOption("maxMemory", 'b',
			"Maximum size of model (in bytes). -1 = no limit.", -1, -1,
			Integer.MAX_VALUE);

	/**
	 * Allows to define the frequency of memory checks.
	 */
	public IntOption memCheckFrequencyOption = new IntOption(
			"memCheckFrequency", 'q',
			"How many instances between memory bound checks.", 1000, 0,
			Integer.MAX_VALUE);

	/**
	 * Allows to define the output file name and location.
	 */
	public FileOption dumpFileOption = new FileOption("dumpFile", 'd',
			"File to append intermediate csv reslts to.", null, "csv", true);

	/**
	 * Defines the task's result type.
	 */
	public Class<?> getTaskResultType() {
		return LearningCurve.class;
	}

	@Override
	protected Object doMainTask(TaskMonitor monitor, ObjectRepository repository) {
		OALE learner = (OALE)getPreparedClassOption(this.learnerOption);
		ExampleStream stream = (ExampleStream) getPreparedClassOption(this.streamOption);
		LearningPerformanceEvaluator evaluator = (LearningPerformanceEvaluator) getPreparedClassOption(this.evaluatorOption);
		LearningCurve learningCurve = new LearningCurve(
				"learning evaluation instances");
		
		learner.setModelContext(stream.getHeader());		
		int maxInstances = this.instanceLimitOption.getValue();
		int maxSeconds = this.timeLimitOption.getValue();
		int secondsElapsed = 0;		
		monitor.setCurrentActivity("Evaluating learner...", -1.0);
		
		
		
		int chunkSize = this.chunkSizeOption.getValue();		
		learner.chunkSizeOption.setValue(chunkSize);
        learner.prepareForUse();
		learner.resetLearningImpl();		
		
		//long instancesProcessed = 0;

		File dumpFile = this.dumpFileOption.getFile();
		PrintStream immediateResultStream = null;
		if (dumpFile != null) {
			try {
				if (dumpFile.exists()) {
					immediateResultStream = new PrintStream(
							new FileOutputStream(dumpFile, false), true);
				} else {
					immediateResultStream = new PrintStream(
							new FileOutputStream(dumpFile), true);
				}
			} catch (Exception ex) {
				throw new RuntimeException(
						"Unable to open immediate result file: " + dumpFile, ex);
			}
		}
		
        boolean firstDump = true;
        boolean preciseCPUTiming = TimingUtils.enablePreciseTiming();
        long evaluateStartTime = TimingUtils.getNanoCPUTimeOfCurrentThread();

		long sampleTestTime =0, sampleTrainTime = 0;
		double RAMHours = 0.0;
		
		int numberSamples=0;
		int numFirstSamples=chunkSize-1;
		
		
		
		
		
		
		//�����￪ʼ������������������Ҫ��ʵ������һ���������ж����ҵ��������	 
		while (stream.hasMoreInstances()
				&& ((maxInstances < 0) || (numberSamples < maxInstances))
				&& ((maxSeconds < 0) || (secondsElapsed < maxSeconds))) {
			
			Instance traininst = (Instance) stream.nextInstance().getData();  
			//�������ڵ�һ�������֮ǰ������һֱ�ǲ��ϵؼ����ģ���0��ʼһֱ����Ĵ�С
			if(numberSamples > numFirstSamples)
			{
				long testStartTime = TimingUtils.getNanoCPUTimeOfCurrentThread();
				Instance testinstance = learner.currentChunk[learner.iterationControl];//learner����AE��һ�����󣬰�������һЩ����
				double[] prediction = learner.getVotesForInstance(testinstance);
				//����ط�����ʹ��pretiction����һ����innstance������������ֵ�����ǽ�����Ԥ��������ֵ�����Եò�������������ļ��������
				// Output prediction
				Example testInst = new InstanceExample(testinstance);
				evaluator.addResult((InstanceExample) testInst, prediction);
				
				sampleTestTime += TimingUtils.getNanoCPUTimeOfCurrentThread() - testStartTime;
				long trainStartTime = TimingUtils.getNanoCPUTimeOfCurrentThread();
				
				learner.trainOnInstance(traininst);
				numberSamples++;
				sampleTrainTime += TimingUtils.getNanoCPUTimeOfCurrentThread() - trainStartTime;
				
				if (learner.processedInstances% this.sampleFrequencyOption.getValue() == 0
	                    || stream.hasMoreInstances() == false) {
					
					double RAMHoursIncrement = learner.measureByteSize() / (1024.0 * 1024.0 * 1024.0); //GBs
	                RAMHoursIncrement *= (TimingUtils.nanoTimeToSeconds(sampleTrainTime + sampleTestTime) / 3600.0); //Hours
	                RAMHours += RAMHoursIncrement;
					double avgTrainTime = TimingUtils.nanoTimeToSeconds(sampleTrainTime)/((double)this.sampleFrequencyOption.getValue()/chunkSize);
					double avgTestTime = TimingUtils.nanoTimeToSeconds(sampleTestTime)/((double)this.sampleFrequencyOption.getValue()/chunkSize);
					sampleTestTime = 0;
					sampleTrainTime = 0;
					
	                learningCurve.insertEntry(new LearningEvaluation(
	                        new Measurement[]{
	                            new Measurement("learning evaluation instances",learner.processedInstances),
	                            new Measurement(("evaluation time ("+ (preciseCPUTiming ? "cpu " : "") + "seconds)"),TimingUtils.nanoTimeToSeconds(TimingUtils.getNanoCPUTimeOfCurrentThread() - evaluateStartTime)),
	                            new Measurement("average chunk train time", avgTrainTime),
	    						new Measurement("average chunk train speed", chunkSize / avgTrainTime),
	    						new Measurement("average chunk test time", avgTestTime),
	    						new Measurement("average chunk test speed", chunkSize/ avgTestTime),
	    						new Measurement( "model cost (RAM-Hours)", RAMHours)}, 
	                        evaluator, learner));

	                if (immediateResultStream != null) {
	                    if (firstDump) {
	                        immediateResultStream.println(learningCurve.headerToString());
	                        firstDump = false;
	                    }
	                    immediateResultStream.println(learningCurve.entryToString(learningCurve.numEntries() - 1));
	                    immediateResultStream.flush();
	                }
	            }
	            if (learner.processedInstances % INSTANCES_BETWEEN_MONITOR_UPDATES == 0) {
	                if (monitor.taskShouldAbort()) {
	                    return null;
	                }
	                long estimatedRemainingInstances = stream.estimatedRemainingInstances();
	                if (maxInstances > 0) {
	                    long maxRemaining = maxInstances - learner.processedInstances;
	                    if ((estimatedRemainingInstances < 0)
	                            || (maxRemaining < estimatedRemainingInstances)) {
	                        estimatedRemainingInstances = maxRemaining;
	                    }
	                }
	                monitor.setCurrentActivityFractionComplete(estimatedRemainingInstances < 0 ? -1.0
	                        : (double) learner.processedInstances
	                        / (double) (learner.processedInstances + estimatedRemainingInstances));
	                if (monitor.resultPreviewRequested()) {
	                    monitor.setLatestResultPreview(learningCurve.copy());
	                }
	                secondsElapsed = (int) TimingUtils.nanoTimeToSeconds(TimingUtils.getNanoCPUTimeOfCurrentThread()
	                        - evaluateStartTime);
	            }
			}
			else if(numberSamples < numFirstSamples)//filling the first chunk
			{
				learner.currentChunk[numberSamples]=traininst;				
			}
			else//createFirstBaseLearner
			{
				learner.currentChunk[numberSamples]=traininst;
				learner.createNewBaseLearner();
			}
			
			numberSamples++;			
		}
		
		if(learner.sumBaseLearners !=0){
			sampleTestTime = 0;
			sampleTrainTime = 0;
			for(int i=0;i<chunkSize;i++)
	    	{
				long testStartTime = TimingUtils.getNanoCPUTimeOfCurrentThread();
				Instance testinstance = learner.currentChunk[learner.iterationControl];
				double[] prediction = learner.getVotesForInstance(testinstance);
				// Output prediction
				Example testInst = new InstanceExample(testinstance);
				//addResult�ķ�����������Ľ��
				evaluator.addResult((InstanceExample) testInst, prediction);
				sampleTestTime += TimingUtils.getNanoCPUTimeOfCurrentThread() - testStartTime;		
				long trainStartTime = TimingUtils.getNanoCPUTimeOfCurrentThread();
				learner.trainOnInstance(testinstance);
				numberSamples++;
				sampleTrainTime += TimingUtils.getNanoCPUTimeOfCurrentThread() - trainStartTime;
	    	}

					double RAMHoursIncrement = learner.measureByteSize() / (1024.0 * 1024.0 * 1024.0); //GBs
	                RAMHoursIncrement *= (TimingUtils.nanoTimeToSeconds(sampleTrainTime + sampleTestTime) / 3600.0); //Hours
	                RAMHours += RAMHoursIncrement;
					
					double avgTrainTime = TimingUtils.nanoTimeToSeconds(sampleTrainTime)/((double)chunkSize);
					double avgTestTime = TimingUtils.nanoTimeToSeconds(sampleTestTime)/((double)chunkSize);
					
	                learningCurve.insertEntry(new LearningEvaluation(
	                        new Measurement[]{
	                            new Measurement("learning evaluation instances",learner.processedInstances),
	                            new Measurement(("evaluation time ("+ (preciseCPUTiming ? "cpu " : "") + "seconds)"),TimingUtils.nanoTimeToSeconds(TimingUtils.getNanoCPUTimeOfCurrentThread() - evaluateStartTime)),
	                            new Measurement("average chunk train time", avgTrainTime),
	    						new Measurement("average chunk train speed", chunkSize / avgTrainTime),
	    						new Measurement("average chunk test time", avgTestTime),
	    						new Measurement("average chunk test speed", chunkSize/ avgTestTime),
	    						new Measurement( "model cost (RAM-Hours)", RAMHours)}, 
	                        evaluator, learner));

	                if (immediateResultStream != null) {
	                    if (firstDump) {
	                        immediateResultStream.println(learningCurve.headerToString());
	                        firstDump = false;
	                    }
	                    immediateResultStream.println(learningCurve.entryToString(learningCurve.numEntries() - 1));
	                    immediateResultStream.flush();
	                }
	    	}
		if (immediateResultStream != null) {
			immediateResultStream.close();
		}
		return learningCurve;
	}

}

/*
 *    ActiveEnsemble.java
 *    Copyright (C) 2018 National University of Defense Technology, Changsha, China
 *    @author Shan Jicheng(shanjicheng@nudt.edu.cn)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.classifiers.active;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import moa.classifiers.AbstractClassifier;
import moa.classifiers.Classifier;
import moa.core.DoubleVector;
import moa.core.Measurement;
import moa.core.ObjectRepository;
import moa.options.ClassOption;
import com.github.javacliparser.FloatOption;
import com.github.javacliparser.IntOption;
import moa.tasks.TaskMonitor;
import weka.classifiers.trees.J48;
import weka.core.FastVector;

import com.yahoo.labs.samoa.instances.Attribute;
import com.yahoo.labs.samoa.instances.Instance;
import com.yahoo.labs.samoa.instances.Instances;
import moa.core.Utils;

/**
 * 
 * 
 */
public class OALE extends AbstractClassifier {

	private static final long serialVersionUID = 1L;
	 
    @Override
    public String getPurposeString() {
        return "Online Active Ensemble classifier as proposed by Shan et al. ";
    }
    
    /**
     * Type of classifier to use as a component classifier.
     */
    public ClassOption learnerOption = new ClassOption("learner", 'l', "Classifier to train.", Classifier.class,
    		"trees.HoeffdingTree -e 2000000 -g 100 -c 0.01");  
    /**
     * Number of component classifiers.
     */
    public IntOption memberCountOption = new IntOption("memberCount",
    		'n', "The maximum number of classifier in an ensemble.", 10, 1, Integer.MAX_VALUE);    
    /**
     * Chunk size.
     */
    public IntOption chunkSizeOption = new IntOption("chunkSize",
    		'c', "The chunk size used for classifier creation and evaluation.", 500, 1, Integer.MAX_VALUE);
    
    public FloatOption selectionSizeOption = new FloatOption("selectionSize", 
    		'r',"The percentenge of random selection size.",
    		0.1, 0.0, 0.5);

    public FloatOption fixedThresholdOption = new FloatOption("fixedThreshold",
            'u', "Fixed threshold.",
            0.5, 0.00, 0.5);

    public FloatOption PerofRandOption = new FloatOption("PerofRandOption",
            'p', "Percentenge of random strategy labled .",
            0.01, 0.00, 1.00);
    
    public FloatOption StepOption = new FloatOption("StepOption",
            's', "Threshold adjustment step.",
            0.01, 0.00, 1.00);
    
    public FloatOption StableWeight = new FloatOption("StableWeight",
            'w', "Weight of stable classifier.",
            0.5, 0.00, 1.00);
    
	protected static int numberOfAttributes;         //attribute number
	protected static int numberOfClasses;                     //class number

	protected int selectionSize;                    // every time we add selectionSize to train
	protected int currentBaseLearnerNo=-1;          // current Base Learner No.  
  
	public static int iterationControl=0;
	protected  int costLabeling=0;
	protected  int correctcount = 0;
	public  int sumBaseLearners=0; 
	protected  double newThreshold;
	protected Random rd1 = new Random();
    protected  Classifier[] ensemble;

    protected double[] ensembleWeights;

    public static int processedInstances=0;

    protected Classifier candidateClassifier;
    protected static Classifier StableClassifier;

    public static Instance[] currentChunk;
    /**
	 * Class distributions.
	 */
	protected long[] classDistributions;
	
    @Override
    public void prepareForUseImpl(TaskMonitor monitor, ObjectRepository repository) {

        StableClassifier = ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        this.ensemble = new Classifier[this.memberCountOption.getValue()];
        this.ensembleWeights = new double[this.memberCountOption.getValue()];
        
        for(int i=0;i<this.memberCountOption.getValue();i++)
        {
        	this.ensemble[i]= ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        }
         
        super.prepareForUseImpl(monitor, repository);
    }

    @Override
    public void resetLearningImpl() {
        
        StableClassifier.resetLearning();
    	for(int i=0;i<this.memberCountOption.getValue();i++)
        {
        	this.ensemble[i].resetLearning();
        	this.ensembleWeights[i]=0;
        }
        
        selectionSize = (int)(this.selectionSizeOption.getValue()*this.chunkSizeOption.getValue());
        currentChunk = new Instance[this.chunkSizeOption.getValue()];

        newThreshold = (fixedThresholdOption.getValue()*2)/numberOfClasses;
        
        currentBaseLearnerNo = -1;
        correctcount=0;
        costLabeling=0;
        processedInstances=0;
        iterationControl=0;
        sumBaseLearners=0;
    }

    @Override
    public void trainOnInstanceImpl(Instance inst) 
    {
    	dealInstance( inst) ;    	
    } 
    
    public void dealInstance(Instance inst) 
    {
    	initVariables();
    	Instance instance = currentChunk[iterationControl];		//get instance from the buffer    	
        int numEnsembledBaseLearners=Math.min(this.memberCountOption.getValue(),sumBaseLearners);
    	////Uncertainty strategy    	
        if (UncertaintyStrategy(instance))
        { ///label instance and train on it
        	StableClassifier.trainOnInstance(instance);
        	for(int j=0; j<numEnsembledBaseLearners; j++)
        	{
        		ensemble[j].trainOnInstance(instance);
        	}
        	costLabeling++;
        	newThreshold =newThreshold* ((double)1 - StepOption.getValue());
        } 
        else
        {
        	///Random strategy
            if(RandomStrategy())
            {  	///label instance and train on it
            	StableClassifier.trainOnInstance(instance);             	
             	for(int j=0; j<numEnsembledBaseLearners; j++)
             	{
             		ensemble[j].trainOnInstance(instance);
             	}
             	costLabeling++;
            }
        }
        
        processedInstances++;
    	currentChunk[iterationControl]=inst;     ///new inst replace dealed instance in buffer  
        iterationControl=(iterationControl+1)%this.chunkSizeOption.getValue();
        
        if(iterationControl==0)         ///new instances fulfill the buffer again
        	createNewBaseLearner();
	}  
    
    public boolean UncertaintyStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);			//ensemble prediction
        int maxIndex = Utils.maxIndex(count);                       
        double maxDistr=count[maxIndex];
        count[maxIndex]=0;
        int secondMaxIndex = Utils.maxIndex(count);    	        
        double margin = maxDistr-count[secondMaxIndex];  //get EnsembleMargin(instance)
        if (margin <= newThreshold)
        { 
        	newThreshold =newThreshold* ((double)1 - StepOption.getValue());
        	return true;
        } 
        else
        {
        	return false;
        }
    }
    
    public boolean RandomStrategy(){
    	if(rd1.nextDouble() < PerofRandOption.getValue())
        {
    		return true;
        } 
        else
        {
        	return false;
        }
    }
    
    public void createNewBaseLearner() {
    	int labeled = 0;
    	Random rd2 = new Random();
    	boolean[] selected = new boolean[this.chunkSizeOption.getValue()];
        sumBaseLearners++;
        currentBaseLearnerNo=(currentBaseLearnerNo+1)%this.memberCountOption.getValue();//dynamic classifier replacement
        ensemble[currentBaseLearnerNo].resetLearning();
        ensembleWeights[currentBaseLearnerNo]=0;
        
        while(labeled < selectionSize)
        {
        	int no = (int)(rd2.nextFloat() * this.chunkSizeOption.getValue());
        	if(!selected[no]){
       			StableClassifier.trainOnInstance(currentChunk[no]);
       			ensemble[currentBaseLearnerNo].trainOnInstance(currentChunk[no]);
       			selected[no] = true;
       			labeled++;
       		}
       	}
        
       double sumWeight =0;
    	
  	   int numEnsembledBaseLearners=Math.min(sumBaseLearners,this.memberCountOption.getValue());
       for(int i=0; i<numEnsembledBaseLearners;i++){           
    	   ensembleWeights[i] = ensembleWeights[i]*((double)1-(double)1/numEnsembledBaseLearners);
           sumWeight += ensembleWeights[i];
       }
       
       ensembleWeights[currentBaseLearnerNo]=(double)1/(numEnsembledBaseLearners);
       sumWeight +=(double)1/(numEnsembledBaseLearners);
       for(int i=0; i<numEnsembledBaseLearners;i++){           
    	   ensembleWeights[i] = ensembleWeights[i]/sumWeight;
       }       
       costLabeling+=labeled;
       newThreshold = (fixedThresholdOption.getValue()*2)/numberOfClasses;

    }  


    public void dealLastChunk()
    {
    	if(sumBaseLearners==0) // can not create stableLearner
    		return;
    	for(int i=0;i<this.chunkSizeOption.getValue();i++)
    	{
        	Instance inst = currentChunk[i];
    		dealInstance( inst);
    	}
    	
    }


    /**
     * Initiates  class distribution variables.
     */
    private void initVariables()
    {

        if (this.classDistributions == null) {
            this.classDistributions = new long[this.getModelContext().classAttribute().numValues()];

            for (int i = 0; i < this.classDistributions.length; i++) {
                this.classDistributions[i] = 0;
            }
            numberOfClasses = this.getModelContext().classAttribute().numValues();
            numberOfAttributes = this.getModelContext().numAttributes();
        }
    }

    /**
     * Predicts a class for an example.
     */
    @Override
    public double[] getVotesForInstance(Instance inst) {
      
    	double[] instanceDistribution = null;
    	double[] count = new double[numberOfClasses];
    	for(int k=0; k<numberOfClasses;k++)
    		count[k]=0;
 		///stable classifier votes
    	instanceDistribution = StableClassifier.getVotesForInstance(inst);
        DoubleVector vote = new DoubleVector(instanceDistribution);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            instanceDistribution = vote.getArrayRef();
            for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
            {
                  count[k]=StableWeight.getValue()*instanceDistribution[k];
            }            
        }
        ///dynamic classifier votes
        int numEnsembledBaseLearners=Math.min(this.memberCountOption.getValue(),sumBaseLearners);
        for(int j=0; j<numEnsembledBaseLearners; j++)
        {
            instanceDistribution = ensemble[j].getVotesForInstance(inst);
            vote = new DoubleVector(instanceDistribution);
            if (vote.sumOfValues() > 0.0)
            {
                vote.normalize();
                instanceDistribution = vote.getArrayRef();
            	for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
                {
            		count[k]+=ensembleWeights[j]*instanceDistribution[k];
                }
            }
        }
        ///ensemble votes
        vote = new DoubleVector(count);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            count = vote.getArrayRef();
        }
        else
        {
        	for(int k=0; k<numberOfClasses;k++)
        		count[k]=0;
        }  
        return count;
    }

    @Override
    public boolean correctlyClassifies(Instance instance){
		int classlable = (int)instance.classValue();
		double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);               //ensemble prediction
	    return classlable==maxIndex;
}
    
    @Override
    public void getModelDescription(StringBuilder out, int indent) {
    }

    /**
     * Adds labeling cost and new threshold to the measurements.
     */
    @Override
    protected Measurement[] getModelMeasurementsImpl() {
    	 List<Measurement> measurementList = new LinkedList<Measurement>();
         measurementList.add(new Measurement("labeling cost", 1.0 *this.costLabeling/this.processedInstances));
         //measurementList.add(new Measurement("newThreshold", this.newThreshold));
         return measurementList.toArray(new Measurement[measurementList.size()]);
    }

    /**
     * Determines whether the classifier is randomizable.
     */
    public boolean isRandomizable() {
        return false;
    }

    @Override
    public Classifier[] getSubClassifiers() {
        return this.ensemble.clone();
    }   
}

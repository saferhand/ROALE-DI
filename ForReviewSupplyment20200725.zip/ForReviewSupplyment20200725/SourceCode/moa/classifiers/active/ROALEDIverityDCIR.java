/*
 *    ActiveEnsemble.java
 *    Copyright (C) 2018 National University of Defense Technology, Changsha, China
 *    @author Shan Jicheng(shanjicheng@nudt.edu.cn)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.classifiers.active;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import moa.classifiers.AbstractClassifier;
import moa.classifiers.Classifier;
import moa.core.DoubleVector;
import moa.core.Measurement;
import moa.core.ObjectRepository;
import moa.options.ClassOption;
import com.github.javacliparser.FloatOption;
import com.github.javacliparser.IntOption;
import moa.tasks.TaskMonitor;
import com.yahoo.labs.samoa.instances.Instance;
import moa.core.Utils;

/**
 * 
 * 
 */
public class ROALEDIverityDCIR extends AbstractClassifier {

	private static final long serialVersionUID = 1L;
	 
    @Override
    public String getPurposeString() {
        return "Online Active Ensemble classifier for concept drift and class imbalance. ";
    }
    
    /**
     * Type of classifier to use as a component classifier.
     */
    public ClassOption learnerOption = new ClassOption("learner", 'l', "Classifier to train.", Classifier.class,
    		"trees.HoeffdingTree -e 2000000 -g 100 -c 0.01"); 
//        		"trees.HoeffdingTree");    
    		
    /**
     * Number of component classifiers.
     */
    public IntOption memberCountOption = new IntOption("memberCount",
    		'n', "The maximum number of classifier in an ensemble.", 10, 1, Integer.MAX_VALUE);    
    /**
     * Chunk size.
     */
    public IntOption chunkSizeOption = new IntOption("chunkSize",
    		'c', "The chunk size used for classifier creation and evaluation.", 500, 1, Integer.MAX_VALUE);
    
    public IntOption minclassLabelNumOption = new IntOption("minclassLabelNum",
    		'm', "The size of the sample window used for class imbalance resample.", 1, 0, Integer.MAX_VALUE);
    
   
    public FloatOption selectionSizeOption = new FloatOption("selectionSize", 
    		'r',"The percentenge of random selection size.",
    		0.1, 0.0, 0.5);

    public FloatOption fixedThresholdOption = new FloatOption("fixedThreshold",
            'u', "Fixed threshold.",
            0.5, 0.00, 0.5);

    public FloatOption PerofRandOption = new FloatOption("PerofRandOption",
            'p', "Percentenge of random strategy labled .",
            0.01, 0.00, 1.00);
    
    public FloatOption StepOption = new FloatOption("StepOption",
            's', "Threshold adjustment step.",
            0.01, 0.00, 1.00);
    
    public FloatOption StableWeight = new FloatOption("StableWeight",
            'w', "Weight of stable classifier.",
            0.5, 0.00, 1.00);
    
	protected  int numberOfAttributes;         //attribute number
	protected  int numberOfClasses;            //class number

	protected int selectionSize;                    // every time we add selectionSize to train
	protected int currentBaseLearnerNo=-1;          // current Base Learner No.
	public  int iterationControl=0;
	protected  int costLabeling=0;
	protected  int correctcount = 0;
	public  int sumBaseLearners=0; 
	protected  double newThreshold;
	protected Random rd1 = new Random();
    protected  Classifier[] ensemble;

    protected double[] ensembleWeights;
    public  int processedInstances=0;
    protected Classifier candidateClassifier;
    protected  Classifier StableClassifier;
    protected  int initCorrectednum=0;
    protected double newStableWeight=0;

    public  Instance[] currentChunk;
    /**
	 * Class distributions.
	 */
	protected long[] classDistributions;
	protected int classLowerlimit;
	protected double imbalanceratio;
	protected double imbalancethreshold;
	public class ClassInfo{ 
		public double[] initsampleNum;
		public Vector<Instance> newlabelingSamples;
		public double imbRatio;
	}
	protected ClassInfo[] classinformation;
	boolean[] selected;
	//initVariables();
    public void initVariables(){
    	///added by 
        if (this.classDistributions == null) {
            numberOfClasses = this.getModelContext().numClasses();
    	    numberOfAttributes = this.getModelContext().numAttributes();  
        	this.classDistributions = new long[numberOfClasses];
            for (int i = 0; i < numberOfClasses; i++) {
                this.classDistributions[i] = 0;
            }
            newStableWeight=StableWeight.getValue();  
		    newThreshold =Math.max(0.1, (fixedThresholdOption.getValue()*2)/(double)numberOfClasses);
	        selectionSize = (int)(this.selectionSizeOption.getValue()*this.chunkSizeOption.getValue());
	        this.classLowerlimit=this.minclassLabelNumOption.getValue();
	        this.imbalancethreshold = this.PerofRandOption.getValue();
	        selected = new boolean[chunkSizeOption.getValue()];
	        classinformation = new ClassInfo[numberOfClasses];
	        for (int k = 0; k < numberOfClasses; k++){
	        	classinformation[k]= new ClassInfo();
	        	classinformation[k].imbRatio=0.0;
	        	classinformation[k].newlabelingSamples =new  Vector<Instance>();
	        	classinformation[k].initsampleNum = new double[this.memberCountOption.getValue()];
	        }           
        }
    }
			
	public void createNewBaseLearner() {

	    	int labeled = 0;
	    	int initSelectednum=0;
		    newThreshold = (fixedThresholdOption.getValue()*2)/(double)numberOfClasses;
		    imbalancethreshold = this.PerofRandOption.getValue();
		    double tmpThreshold=newThreshold;
	    	Random rd2 = new Random();
	    	int[] selNumbers= new int[numberOfClasses];
	    	for(int i=0; i<numberOfClasses; i++)
	    	{
	    		selNumbers[i]=0;
	    	}
	        if(sumBaseLearners < this.memberCountOption.getValue())
	        	currentBaseLearnerNo=sumBaseLearners;
	        else
	        	currentBaseLearnerNo = Utils.minIndex(ensembleWeights); 
 	        
	        sumBaseLearners++;
	        //currentBaseLearnerNo=(currentBaseLearnerNo+1)%this.memberCountOption.getValue();//dynamic classifier replacement
	        int numEnsembledBaseLearners=Math.min(this.memberCountOption.getValue(),sumBaseLearners);
	        
	        
	        //learn all instances in the first data block
	        if(sumBaseLearners==1)
	        	//initSelectednum=this.chunkSizeOption.getValue();
	        	initSelectednum=selectionSize;
	        else
	        	initSelectednum=selectionSize;

	    	for(int i=0; i<this.chunkSizeOption.getValue(); i++)
	    	{
	    		selected[i]=false;
	    	}
	        double weightfactor=1;
	        
	        Vector<Instance> allinitRandSamples= new  Vector<Instance>();
	      //Stage1
	        while(labeled < initSelectednum)
	        {
	        	int no = (int)(rd2.nextFloat() * this.chunkSizeOption.getValue());
		        if(sumBaseLearners==1)
		        	no=labeled;
	        	if(!selected[no]){
	            	int classlable = (int)currentChunk[no].classValue();
	              	selNumbers[classlable]++;
	              	allinitRandSamples.addElement(currentChunk[no]);
	              	if( correctlyClassifies(currentChunk[no]))
	              		newThreshold =newThreshold*((double)1 - StepOption.getValue());	 
	              	else if(classinformation[classlable].imbRatio < 1/(double)(numberOfClasses) )
			             	for(int j=0; j<numEnsembledBaseLearners; j++)
			             		if(!ensemble[j].correctlyClassifies(currentChunk[no]))
			             			ensembleWeights[j]*=(1 - 1/(double)(1+numEnsembledBaseLearners));
			             		else
			             			ensembleWeights[j]*=(1 + 1/(double)(1+numEnsembledBaseLearners));
	              	selected[no] = true;
	       			labeled++;
	       		}       	
	       	}//End While
	        
          	//Stage2
	        ensemble[currentBaseLearnerNo].resetLearning();
	        for (int i = 0;i < numberOfClasses;i++){
	        	classinformation[i].imbRatio=0;
	        	classinformation[i].initsampleNum[currentBaseLearnerNo] = selNumbers[i];
	        	if (selNumbers[i] < this.classLowerlimit){
	        		int numNeedmore = this.classLowerlimit - selNumbers[i];
	        		int numSavesample=classinformation[i].newlabelingSamples.size();
	        		int minNum = Math.min(numNeedmore, numSavesample);
	        		
               		for (int j = minNum; j >0; j--){
               			Instance sample =classinformation[i].newlabelingSamples.get(numSavesample-j);
               			ensemble[currentBaseLearnerNo].trainOnInstance(sample);
               		}
 	 	        }
	        }//end for
    
		    for(Instance inst: allinitRandSamples){
		    	  int classlable = (int)inst.classValue();
		    	  classinformation[classlable].newlabelingSamples.addElement(inst);
	       			StableClassifier.trainOnInstance(inst);
	            	for(int j=0; j<numEnsembledBaseLearners; j++)
	            		ensemble[j].trainOnInstance(inst);
		    }

	       double sumWeight =0;
	       ensembleWeights[currentBaseLearnerNo]=0;

	       for(int i=0; i<numEnsembledBaseLearners;i++){           
	    	   ensembleWeights[i] = ensembleWeights[i]*(1-1/(double)numEnsembledBaseLearners);
	           sumWeight += ensembleWeights[i];
	       }

	       ensembleWeights[currentBaseLearnerNo]=weightfactor*1/(double)(numEnsembledBaseLearners);
	       sumWeight +=ensembleWeights[currentBaseLearnerNo];

	       double sumweightNum=0;
	       for(int i=0; i<numEnsembledBaseLearners;i++){           
	    	   ensembleWeights[i] = ensembleWeights[i]/sumWeight;
		       for (int j = 0;j < numberOfClasses;j++){
		    	   double dNum = classinformation[j].initsampleNum[i]* ensembleWeights[i];
		    	   classinformation[j].imbRatio = classinformation[j].imbRatio + dNum;
		    	   sumweightNum = sumweightNum + dNum;
		       }
	       }       
	       costLabeling+=labeled;       
	       for (int i = 0;i < numberOfClasses;i++){
	    	  int leng=classinformation[i].newlabelingSamples.size() - classLowerlimit;
    		  for (int j = 0;j < leng;j++)
    			  classinformation[i].newlabelingSamples.remove(0);
    		  if(sumweightNum>0)
    			  classinformation[i].imbRatio =(classinformation[i].imbRatio/sumweightNum);
    		  else 
    			  classinformation[i].imbRatio=1;
 	       }    

    }
	

	
    @Override
    public void prepareForUseImpl(TaskMonitor monitor, ObjectRepository repository) {
        StableClassifier = ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        this.ensemble = new Classifier[this.memberCountOption.getValue()];
        this.ensembleWeights = new double[this.memberCountOption.getValue()];
        for(int i=0;i<this.memberCountOption.getValue();i++)
        {
        	this.ensemble[i]= ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        }
        super.prepareForUseImpl(monitor, repository);
    }

    @Override
    public void resetLearningImpl() {

        StableClassifier.resetLearning();
    	for(int i=0;i<this.memberCountOption.getValue();i++)
        {
        	this.ensemble[i].resetLearning();
        	this.ensembleWeights[i]=0;
        }
        currentChunk = new Instance[this.chunkSizeOption.getValue()];
        currentBaseLearnerNo = -1;
        correctcount=0;
        costLabeling=0;
        processedInstances=0;
        iterationControl=0;
        sumBaseLearners=0;
        //System.out.println("Yes");
    }

    @Override
    public void trainOnInstanceImpl(Instance inst) 
    {
    	dealInstance( inst) ;    	
    } 
    
    public void dealInstance(Instance inst) 
    {
    	Instance instance = currentChunk[iterationControl];		//get instance from the buffer    	
        int numEnsembledBaseLearners=Math.min(this.memberCountOption.getValue(),sumBaseLearners);
    	////Uncertainty strategy    	
        if (UncertaintyStrategy(instance))
        { ///label instance and train on it
          	if( correctlyClassifies(instance))
          		newThreshold =newThreshold* ((double)1 - StepOption.getValue());
        	StableClassifier.trainOnInstance(instance);
        	for(int j=0; j<numEnsembledBaseLearners; j++)
        	{
        		ensemble[j].trainOnInstance(instance);
        	}
        	costLabeling++;
        	//newThreshold =newThreshold* ((double)1 - StepOption.getValue())* ((double)1 - StepOption.getValue());
        	newThreshold =newThreshold* ((double)1 - StepOption.getValue());
        	classinformation[(int)instance.classValue()].newlabelingSamples.addElement(instance);
        } 
        else
        {
        	//Random strategy
            if(!selected[iterationControl] && RandomStrategy(instance))
            {  	//label instance and train on it
              	if(!correctlyClassifies(instance)){
	    			int classlable = (int)instance.classValue();
	    			if(classinformation[classlable].imbRatio < 1/((double)numberOfClasses) ) 
		             	for(int j=0; j<numEnsembledBaseLearners; j++)
		             		if(!ensemble[j].correctlyClassifies(instance))
		             			ensembleWeights[j]*=(1 - 1/(1+(double)numEnsembledBaseLearners));
		             		else
		             			ensembleWeights[j]*=(1 + 1/(1+(double)numEnsembledBaseLearners));
              	}
            	StableClassifier.trainOnInstance(instance);             	
             	for(int j=0; j<numEnsembledBaseLearners; j++)
             		ensemble[j].trainOnInstance(instance);
            	costLabeling++;
            	classinformation[(int)instance.classValue()].newlabelingSamples.addElement(instance);
            }
        }
        processedInstances++;
    	currentChunk[iterationControl]=inst;     //new inst replace dealed instance in buffer  
        iterationControl=(iterationControl+1)%this.chunkSizeOption.getValue();
        if(iterationControl==0)         //new instances fulfill the buffer again
        	createNewBaseLearner();
	} 

    public boolean UncertaintyStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);                       
        double maxDistr=count[maxIndex];
        count[maxIndex]=0;
        int secondMaxIndex = Utils.maxIndex(count);    	        
        double margin = maxDistr-count[secondMaxIndex];
        if (margin <= newThreshold)
        	return true;
        else
        	return false;
    }
    
    public boolean RandomStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);
    	int maxIndex = Utils.maxIndex(count); 
    	double tmpRanthreshold=this.imbalancethreshold;
    	if(classinformation[maxIndex].imbRatio > 0)
    		tmpRanthreshold=Math.max(tmpRanthreshold,this.imbalancethreshold/(double)(numberOfClasses*classinformation[maxIndex].imbRatio));
    	else
    		tmpRanthreshold=1;
    	if( rd1.nextDouble() < tmpRanthreshold )
        {
    		return true;
        } 
        else
        {
        	return false;
        }
    }
 
    
    public void dealLastChunk()
    {
    	if(sumBaseLearners==0)
    		return;
    	for(int i=0;i<this.chunkSizeOption.getValue();i++)
    	{
        	Instance inst = currentChunk[i];
    		dealInstance( inst);
    	}
    	
    }


     /**
     * Predicts a class for an example.
     */
    @Override
    public double[] getVotesForInstance(Instance inst) {
      
    	double[] instanceDistribution = null;
    	double[] count = new double[numberOfClasses];
    	for(int k=0; k<numberOfClasses;k++)
    		count[k]=0;
 		//stable classifier votes
    	instanceDistribution = StableClassifier.getVotesForInstance(inst);
        DoubleVector vote = new DoubleVector(instanceDistribution);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            instanceDistribution = vote.getArrayRef();
            for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
            {
                  count[k]=newStableWeight*instanceDistribution[k];
            }            
        }
        //dynamic classifier votes
        int numEnsembledBaseLearners=Math.min(this.memberCountOption.getValue(),sumBaseLearners);
        for(int j=0; j<numEnsembledBaseLearners; j++)
        {
            instanceDistribution = ensemble[j].getVotesForInstance(inst);
            vote = new DoubleVector(instanceDistribution);
            if (vote.sumOfValues() > 0.0)
            {
                vote.normalize();
                instanceDistribution = vote.getArrayRef();
            	for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
                {
            		count[k]+=ensembleWeights[j]*instanceDistribution[k];
                }
            }
        }
        //ensemble votes
        vote = new DoubleVector(count);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            count = vote.getArrayRef();
        }
        else
        {
        	for(int k=0; k<numberOfClasses;k++)
        		count[k]=0;
        }  
        return count;
    }

    @Override
    public boolean correctlyClassifies(Instance instance){
		int classlable = (int)instance.classValue();
		double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);               //ensemble prediction
	    return classlable==maxIndex;
}
    
    @Override
    public void getModelDescription(StringBuilder out, int indent) {
    }

    /**
     * Adds labeling cost and new threshold to the measurements.
     */
    @Override
    protected Measurement[] getModelMeasurementsImpl() {
    	 List<Measurement> measurementList = new LinkedList<Measurement>();
    	 double labelingcost = 0;
    	 if(processedInstances > 0){
    		 labelingcost =  1.0 *this.costLabeling/(double)processedInstances;
    	 }
    	 measurementList.add(new Measurement("labeling cost", labelingcost));
    	 measurementList.add(new Measurement("labels number", this.costLabeling));
         measurementList.add(new Measurement("newThreshold", this.newThreshold));
         measurementList.add(new Measurement("limit", this.classLowerlimit));
         measurementList.add(new Measurement("weight", this.ensembleWeights[0]));
	        for (int j = 0; j < numberOfClasses; j++)
	        {
	        	String s = String.valueOf(j);
	        	measurementList.add(new Measurement("imbRatio_"+s, this.classinformation[j].imbRatio));
	        }
         
         return measurementList.toArray(new Measurement[measurementList.size()]);
    }

    /**
     * Determines whether the classifier is ransdomizable.
     */
    public boolean isRandomizable() {
        return false;
    }

    @Override
    public Classifier[] getSubClassifiers() {
        return this.ensemble.clone();
    }   
}

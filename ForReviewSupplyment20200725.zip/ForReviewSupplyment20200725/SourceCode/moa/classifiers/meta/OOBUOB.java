/*
                      *    OzaBag.java
 *    Copyright (C) 2007 University of Waikato, Hamilton, New Zealand
 *    @author Richard Kirkby (rkirkby@cs.waikato.ac.nz)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.classifiers.meta;

import moa.classifiers.AbstractClassifier;
import moa.classifiers.Classifier;
import com.yahoo.labs.samoa.instances.Instance;

import moa.core.DoubleVector;
import moa.core.Measurement;
import moa.core.MiscUtils;
import moa.options.ClassOption;

import java.util.ArrayList;

import com.github.javacliparser.FloatOption;
import com.github.javacliparser.IntOption;


public class OOBUOB extends AbstractClassifier {

    @Override
    public String getPurposeString() {
        return "Incremental on-line bagging of Oza and Russell.";
    }
        
    private static final long serialVersionUID = 1L;

    public ClassOption baseLearnerOption = new ClassOption("baseLearner", 'l',
            "Classifier to train.", Classifier.class, "trees.HoeffdingTree");
    
    public IntOption ensembleSizeOption = new IntOption("ensembleSize", 's',
            "The number of models in the bag.", 10, 1, Integer.MAX_VALUE);
    
    public IntOption methodOption = new IntOption("samplingMethodOOB0UOB1", 'm',
            "Sampling Method 0:OOB,1:UOB.", 0, 0, 1);
    
    public FloatOption sizedecayfactorOption = new FloatOption("sizedecayfactor", 'z',
            "Decay value of size of minority class.", 0.9, 0.00, 1.00);
    
    public FloatOption recalldecayfactorOption = new FloatOption("recalldecayfactorfactor", 'r',
            "Decay value of recall of minority class.", 0.9, 0.00, 1.00);
    
    protected Classifier[] ensemble;

        
    //ADD1-Shuo
    // data stream properties
    public static double[] classPercentage;// class percentage of each class (time decayed) at each time step. 1st index - number of total time steps; 2nd index - number of classes in data streams
    public static boolean imbalance;// whether the current data stream is imbalanced
    public static int numClasses;//number of classes
    public static int[] numInstances;//number of instances of each class
    public static ArrayList<Integer> classIndexMinority = new ArrayList<Integer>();//class indice of current minority classes
    public static ArrayList<Integer> classIndexMajority = new ArrayList<Integer>();//class indice of current majority classes
    public static ArrayList<Integer> classIndexNormal = new ArrayList<Integer>();//class indice of other classes
    // performance at current time step
    public static double[] currentClassRecall_decay;//time decayed recall value of each class at current time step at current run
    public static double[][][] classRecall_prequential;// prequential recall value of each class at each time step at each run
    public static double[][] gmean_prequential;//gmean of prequential recalls at each time step at each run
    public static double[][][] classRecall_decay;// time decayed recall value of each class at each time step at each run
    public static double[][] gmean_decay;//gmean of time decayed recalls at each time step at each run

    String resample = "OOB";//��������޸�
    
    //ADD2-Shuo TypeConvert,Convert the local Vars from the For loop in OOBUOBmain
	protected static int predictedLabel, realLabel;
	protected static boolean isCorrect = true;
	protected static int numSamples_Total = 0;				//number of processed samples from the beginning
	protected static double numSamplesCorrect = 0;			//number of correctly classified samples from the beginning
	
	protected static int[] numInstancesCorrect; 			//number of instances of each class correctly classified
	protected static int[] numInstancesIncorrect; 			//number of instances of each class misclassified into
	protected static int[] numInstancesCorrect_afterchange;	//number of instances of each class correctly classified after change in class imbalance
	protected static int[] numInstances_afterchange;		//number of instances of each class after class imbalance changes         

	protected static double delta1 = 0.4;
	protected static double delta2 = 0.3;
	protected static double sizedecayfactor = 0.9;//theta
	protected static double recalldecayfactor = 0.9;//theta
	

	protected long[] classDistributions;
    
    @Override
    public void resetLearningImpl() {
        this.ensemble = new Classifier[this.ensembleSizeOption.getValue()];
        Classifier baseLearner = (Classifier) getPreparedClassOption(this.baseLearnerOption);
        baseLearner.resetLearning();
        for (int i = 0; i < this.ensemble.length; i++) {
            this.ensemble[i] = baseLearner.copy();
        }
    }

    @Override
    public void trainOnInstanceImpl(Instance inst) {
    	initVariables();
    	double[] prediction = getVotesForInstance(inst);
    	realLabel = (int)inst.classValue();
    	
    	if(predictedLabel==realLabel) isCorrect = true;//Ԥ����ȷ����ָ��
    	else isCorrect = false;
    	
    	numSamples_Total ++;
    	numInstances[realLabel] = numInstances[realLabel]+1;
    	numInstances_afterchange[realLabel]++;//afterchange������Ӧ����      ��ƽ�����֮��      ��������
    	
    	if(isCorrect){//��Ԥ����ȷ,������ȷ��ʵ��������һ,ÿ����������ȷ��������һ,,
    		numSamplesCorrect = numSamplesCorrect+1;//number of correctly classified samples from the beginning
    		numInstancesCorrect[realLabel] = numInstancesCorrect[realLabel]+1;//number of instances of each class correctly classified
			numInstancesCorrect_afterchange[realLabel]++;//number of instances of each class correctly classified after change in class imbalance
    	}
    	else{
    		numInstancesIncorrect[predictedLabel] = numInstancesIncorrect[predictedLabel]+1;//number of instances of each class correctly classified after change in class imbalance
    	}
    	
    	updateClassPercentage(realLabel, numSamples_Total, sizedecayfactor);
    	
    	
    	
    	double lambda = 1.0;
    	//Train/OOU,UOB
    	if(resample.equals("OOB")){
    		//OOB Method
    		//improvedOOB(inst, stableLearner, numSamples_Total);
    		//System.out.println("OOB");
    	    if(classPercentage[realLabel] < classPercentage[1-realLabel]){
    	    	double trainInstancelambda = 0;
    	    	trainInstancelambda = (double)lambda*classPercentage[1-realLabel]/classPercentage[realLabel];
    	    	this.trainEnsembleWithLambda(inst, trainInstancelambda);
    	    }
    	    else
    	    	this.trainEnsembleWithLambda(inst, 1.0);
    	}
    	else if(resample.equals("UOB")){
    		//System.out.println("UOB");
    	    //improvedUOB(inst, stableLearner, numSamples_Total);
    		//UOB Method
    		if(classPercentage[realLabel] > classPercentage[1-realLabel]){
    			double rate = (double)classPercentage[1-realLabel]/classPercentage[realLabel];
    	        if(rate < 0.01)
    	        	this.trainEnsembleWithLambda(inst, (double)lambda*0.01);
    	        else
    	        	this.trainEnsembleWithLambda(inst, (double)lambda*rate);
    		}
    		else
    			this.trainEnsembleWithLambda(inst, lambda);
    	}
    	else
    		//Oral Method
            this.trainEnsembleWithLambda(inst,1.0);  	
    	updateDecayRecall(realLabel, isCorrect, recalldecayfactor);	
    }
    
    public void trainEnsembleWithLambda(Instance inst, double lambda){
    	for (int i = 0; i < this.ensemble.length; i++) {
            int k = MiscUtils.poisson(lambda, this.classifierRandom);
            if (k > 0) {
                Instance weightedInst = (Instance) inst.copy();
                weightedInst.setWeight(inst.weight() * k);
                this.ensemble[i].trainOnInstance(weightedInst);
            }
        }
    }
    
    @Override
    public double[] getVotesForInstance(Instance inst) {
        DoubleVector combinedVote = new DoubleVector();
        for (int i = 0; i < this.ensemble.length; i++) {
            DoubleVector vote = new DoubleVector(this.ensemble[i].getVotesForInstance(inst));
            if (vote.sumOfValues() > 0.0) {
                vote.normalize();
                combinedVote.addValues(vote);
            }
        }
        return combinedVote.getArrayRef();
    }

    @Override
    public boolean isRandomizable() {
        return true;
    }

    @Override
    public void getModelDescription(StringBuilder out, int indent) {
        // TODO Auto-generated method stub
    }

    @Override
    protected Measurement[] getModelMeasurementsImpl() {
        return new Measurement[]{new Measurement("ensemble size",
                    this.ensemble != null ? this.ensemble.length : 0)};
    }

    @Override
    public Classifier[] getSubClassifiers() {
        return this.ensemble.clone();
    }
    
    private void initVariables()
    {
        if (this.classDistributions == null) {
        	///////////////////////////////////////////////////////////////////////
        	//Add the Variables in this place. The Variables will be inited once.//
        	///////////////////////////////////////////////////////////////////////
            this.classDistributions = new long[this.getModelContext().classAttribute().numValues()];
            
            sizedecayfactor = this.sizedecayfactorOption.getValue();
            recalldecayfactor = this.recalldecayfactorOption.getValue();
            
            numClasses = this.getModelContext().classAttribute().numValues();
            
            numInstances = new int[numClasses];
            
            numInstancesCorrect = new int[numClasses]; //number of instances of each class correctly classified
            numInstancesIncorrect = new int[numClasses]; //number of instances of each class misclassified into
            numInstancesCorrect_afterchange = new int[numClasses]; //number of instances of each class correctly classified after change in class imbalance
            numInstances_afterchange = new int[numClasses];//number of instances of each class after class imbalance changes         
            classPercentage = new double[numClasses];
            currentClassRecall_decay = new double[numClasses];
            
            int methodid = this.methodOption.getValue();
            if (methodid == 0)
            	resample = "OOB";
            else
            	resample = "UOB";
            	
            
            
            //System.out.println(numClasses);
           
        }//End If        
    }//End initVariables
    
    //ADD-Functions-1
    public void updateClassPercentage(int realLabel, int numSamplesTotal, double sizedecayfactor){
        if(numSamplesTotal >1){
        	for(int t = 0; t < numClasses; t++){
        		if(t==realLabel)
        			classPercentage[t] = classPercentage[t]*sizedecayfactor+(1-sizedecayfactor);
        		else
        			classPercentage[t] = classPercentage[t]*sizedecayfactor;
        	}//End For
        }
        else{
        	classPercentage[realLabel] = 1;
        }
        //System.out.println(classPercentage[realLabel]);
      }
    
    //ADD-Functions-2
    public static void updateDecayRecall(int realLabel, boolean isCorrect, double recalldecayfactor){
    	if(isCorrect && numInstances[realLabel]==1)
    		currentClassRecall_decay[realLabel] = 1;
    	else if(isCorrect)
    		currentClassRecall_decay[realLabel] = currentClassRecall_decay[realLabel]*recalldecayfactor+(1-recalldecayfactor);
        else if(!isCorrect)
        	currentClassRecall_decay[realLabel] = currentClassRecall_decay[realLabel]*recalldecayfactor;
        
      }
    
    
    
    
    
}

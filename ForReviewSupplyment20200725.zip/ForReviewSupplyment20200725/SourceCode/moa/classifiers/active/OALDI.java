/*
 *    ActiveEnsemble.java
 *    Copyright (C) 2018 National University of Defense Technology, Changsha, China
 *    @author Shan Jicheng(shanjicheng@nudt.edu.cn)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.classifiers.active;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import moa.classifiers.AbstractClassifier;
import moa.classifiers.Classifier;
import moa.core.DoubleVector;
import moa.core.Measurement;
import moa.core.ObjectRepository;
import moa.options.ClassOption;
import com.github.javacliparser.FloatOption;
import com.github.javacliparser.IntOption;
import moa.tasks.TaskMonitor;
import com.yahoo.labs.samoa.instances.Instance;
import moa.core.Utils;

/**
 * 
 * 
 */
public class OALDI extends AbstractClassifier {

	private static final long serialVersionUID = 1L;
	 
    @Override
    public String getPurposeString() {
        return "Online Active Ensemble classifier as proposed by Shan et al. ";
    }
    
    /**
     * Type of classifier to use as a component classifier.
     */
    public ClassOption learnerOption = new ClassOption("learner", 'l', "Classifier to train.", Classifier.class,
    		"trees.HoeffdingTree -e 2000000 -g 100 -c 0.01");
    		
    /**
     * Chunk size.
     */
    public IntOption chunkSizeOption = new IntOption("chunkSize",
    		'c', "The chunk size used for classifier creation and evaluation.", 500, 1, Integer.MAX_VALUE);
    
    public FloatOption selectionSizeOption = new FloatOption("selectionSize", 
    		'r',"The percentenge of random selection size.",
    		0.1, 0.0, 1.0);

    public FloatOption fixedThresholdOption = new FloatOption("fixedThreshold",
            'u', "Fixed threshold.",
            0.5, 0.00, 1.00);

    public FloatOption PerofRandOption = new FloatOption("PerofRandOption",
            'p', "Percentenge of random strategy labled .",
            0.01, 0.00, 1.00);
    
    public FloatOption StepOption = new FloatOption("StepOption",
            's', "Threshold adjustment step.",
            0.01, 0.00, 1.00);

    
	protected static int numberOfAttributes;         //attribute number
	protected static int numberOfClasses;                     //class number
	protected int selectionSize;                    // every time we add selectionSize to train
	protected int currentBaseLearnerNo=-1;          // current Base Learner No.  
	public static int iterationControl=0;
	protected  int costLabeling=0;
	protected  int correctcount = 0;
	public  int sumBaseLearners=0; 
	protected  double newThreshold;
	protected Random rd1 = new Random();
    public static int processedInstances=0;
    protected Classifier candidateClassifier;
    protected static Classifier StableClassifier;
    protected static Classifier DynamicClassifier;
    public static Instance[] currentChunk;
    /**
	 * Class distributions.
	 */
	protected long[] classDistributions;
	protected int[] predictclass;
	protected int[] LBEclassNumbers;
	protected double[] LBEthreshold; 
	protected int[] iniSelectnumberOFEachClass;
	
	
	
    @Override
    public void prepareForUseImpl(TaskMonitor monitor, ObjectRepository repository) {
        StableClassifier = ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        DynamicClassifier = ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        super.prepareForUseImpl(monitor, repository);
    }

    @Override
    public void resetLearningImpl() {
        StableClassifier.resetLearning();
        DynamicClassifier.resetLearning();
        
        selectionSize = (int)(this.selectionSizeOption.getValue()*this.chunkSizeOption.getValue());
        currentChunk = new Instance[this.chunkSizeOption.getValue()];

        newThreshold = (fixedThresholdOption.getValue()*2)/numberOfClasses;
        
        currentBaseLearnerNo = -1;
        correctcount=0;
        costLabeling=0;
        processedInstances=0;
        iterationControl=0;
        sumBaseLearners=0;
    }

    @Override
    public void trainOnInstanceImpl(Instance inst) 
    {
    	dealInstance( inst) ;    	
    }
    
    public void dealInstance(Instance inst) 
    {
    	initVariables();
    	Instance instance = currentChunk[iterationControl];		//get instance from the buffer    	

    	////Uncertainty strategy    	
        if (UncertaintyStrategy(instance))
        { ///label instance and train on it
/*          	if( correctlyClassifies(instance))
          		newThreshold =newThreshold* ((double)1 - StepOption.getValue())* ((double)1 - StepOption.getValue());
*/        	StableClassifier.trainOnInstance(instance);
			DynamicClassifier.trainOnInstance(instance);
        	
        	costLabeling++;
        	newThreshold =newThreshold* ((double)1 - StepOption.getValue());
        } 
        else
        {
        	///Random strategy
            if(ImbalanceStrategy(instance))
            {  	///label instance and train on it
            	StableClassifier.trainOnInstance(instance);
				DynamicClassifier.trainOnInstance(instance);
             	costLabeling++;
            }
        }
        
        processedInstances++;
    	currentChunk[iterationControl]=inst;     ///new inst replace dealed instance in buffer  
        iterationControl=(iterationControl+1)%this.chunkSizeOption.getValue();

        if(iterationControl==0)         ///new instances fulfill the buffer again
        	createNewBaseLearner();
	}  
    
    public boolean UncertaintyStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);			//ensemble prediction
        int maxIndex = Utils.maxIndex(count);                       
        double maxDistr=count[maxIndex];
        count[maxIndex]=0;
        int secondMaxIndex = Utils.maxIndex(count);    	        
        double margin = maxDistr-count[secondMaxIndex];  //get EnsembleMargin(instance)
        if (margin <= newThreshold)
        { 
        	return true;
        } 
        else
        {
        	return false;
        }
    }
    
    public boolean ImbalanceStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);     
    	int maxIndex = Utils.maxIndex(count);                        	   	
    	if(rd1.nextDouble() < LBEthreshold[maxIndex])
        {
    		return true;
        } 
        else
        {
        	return false;
        }
    }
    
    public void createNewBaseLearner() {
    	int labeled = 0;
    	int initSelectednum;
    	Random rd2 = new Random();
    	boolean[] selected = new boolean[this.chunkSizeOption.getValue()];
        sumBaseLearners++;
        
        //ResetDynamicClassifier
        DynamicClassifier.resetLearning();
        
        for (int k = 0; k < numberOfClasses; k++){
        	iniSelectnumberOFEachClass[k]=0;
        	LBEclassNumbers[k]=0;
        }
        
        initVariables();
        
        if(sumBaseLearners>1)
        	initSelectednum=selectionSize;
        else //��һ�����ݿ�����мල��ѧϰ
        	initSelectednum=this.chunkSizeOption.getValue();
        
    	
        while(labeled < initSelectednum)
        {
        	int no = (int)(rd2.nextFloat() * this.chunkSizeOption.getValue());
	        if(sumBaseLearners==1)//
	        	no=labeled;
       	
        	if(!selected[no]){

        		StableClassifier.trainOnInstance(currentChunk[no]);
    			DynamicClassifier.trainOnInstance(currentChunk[no]);

            	
	            int classlable = (int)currentChunk[no].classValue();
	            iniSelectnumberOFEachClass[classlable]++;
	            
       			selected[no] = true;
       			labeled++;
       		}
       	}
        
        
       for (int k = 0; k < numberOfClasses; k++) 
    	   LBEclassNumbers[k]+=iniSelectnumberOFEachClass[k];        
          
       
       costLabeling+=labeled;

       newThreshold = (fixedThresholdOption.getValue()*2)/numberOfClasses;
       
       for (int k = 0; k < numberOfClasses; k++){        	
       	if (LBEclassNumbers[k] > 0)
       		LBEthreshold[k]=Math.max(PerofRandOption.getValue(),(PerofRandOption.getValue()*initSelectednum)/(LBEclassNumbers[k]*numberOfClasses));
       	else
       		LBEthreshold[k] = 1.00;    
       	LBEclassNumbers[k]=0;
       }
      
       
    }  

    public void dealLastChunk()
    {
    	if(sumBaseLearners==0) // can not create stableLearner
    		return;
    	for(int i=0;i<this.chunkSizeOption.getValue();i++)
    	{
        	Instance inst = currentChunk[i];
    		dealInstance( inst);
    	}
    }

    /**
     * Initiates  class distribution variables.
     */
    private void initVariables()
    {

        if (this.classDistributions == null) {
            this.classDistributions = new long[this.getModelContext().classAttribute().numValues()];

            for (int i = 0; i < this.classDistributions.length; i++) {
                this.classDistributions[i] = 0;
            }
            numberOfClasses = this.getModelContext().classAttribute().numValues();
            numberOfAttributes = this.getModelContext().numAttributes();
        }
        
        
        
        if (this.predictclass == null ) {
        	this.predictclass = new int[numberOfClasses];
        	this.LBEclassNumbers = new int[numberOfClasses];
        	this.iniSelectnumberOFEachClass = new int[numberOfClasses];
        	this.LBEthreshold = new double[numberOfClasses];
     	
	        for (int j = 0; j < numberOfClasses; j++)
	        {
	        	this.predictclass[j]=0;    	
	        	this.LBEclassNumbers[j]=0;
	        	this.LBEthreshold[j]=0;
	        	this.iniSelectnumberOFEachClass[j] = 0;
	        }

        }//End if
        
    }

    /**
     * Predicts a class for an example.
     */
    @Override
    public double[] getVotesForInstance(Instance inst) {   
    	double[] instanceDistribution = null;
    	double[] count = new double[numberOfClasses];
    	for(int k=0; k<numberOfClasses;k++)
    		count[k]=0;
    	
 		///stable classifier votes
    	instanceDistribution = StableClassifier.getVotesForInstance(inst);
        DoubleVector vote = new DoubleVector(instanceDistribution);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            instanceDistribution = vote.getArrayRef();
            for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
            {
                  count[k]=0.5*instanceDistribution[k];
            }
        }
        
        
        ///dynamic classifier votes
    	instanceDistribution = DynamicClassifier.getVotesForInstance(inst);
        vote = new DoubleVector(instanceDistribution);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            instanceDistribution = vote.getArrayRef();
            for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
            {
                  count[k]=0.5*instanceDistribution[k];
            }
        }
        
        ///ensemble votes
        vote = new DoubleVector(count);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            count = vote.getArrayRef();
        }
        else
        {
        	for(int k=0; k<numberOfClasses;k++)
        		count[k]=0;
        }
        return count;
    }

    @Override
    public boolean correctlyClassifies(Instance instance){
		int classlable = (int)instance.classValue();
		double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);               //ensemble prediction
	    return classlable==maxIndex;
}
    
    @Override
    public void getModelDescription(StringBuilder out, int indent) {
    }

    /**
     * Adds labeling cost and new threshold to the measurements.
     */
    @Override
    protected Measurement[] getModelMeasurementsImpl() {
    	 List<Measurement> measurementList = new LinkedList<Measurement>();
         measurementList.add(new Measurement("labeling cost", 1.0 *this.costLabeling/this.processedInstances));
         measurementList.add(new Measurement("newThreshold", this.newThreshold));
         return measurementList.toArray(new Measurement[measurementList.size()]);
    }

    /**
     * Determines whether the classifier is randomizable.
     */
    public boolean isRandomizable() {
        return false;
    }

}
